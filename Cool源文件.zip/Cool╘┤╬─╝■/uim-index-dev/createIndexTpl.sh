#!/bin/bash

npm run build
cp -u ../public/vuedist/index.html ../resources/views/material/index.tpl