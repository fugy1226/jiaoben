<?php


namespace App\Models;

class CheckInLog
{
    protected $connection = 'default';
    protected $table = 'ss_checkin_log';
}
